# stdlib
from typing import Any

# third party
import numpy as np
import pandas as pd


class LifelinesWrapper:
    def __init__(self, model: Any, **kwargs: Any) -> None:
        self.model = model

    def fit(self, X: pd.DataFrame, *args: Any, **kwargs: Any) -> "LifelinesWrapper":
        if len(args) < 2:
            raise ValueError("Invalid input for fit. Expecting X, T and Y.")

        T = args[0]
        Y = args[1]

        # 确保为 DataFrame，并记录特征列，预测时恢复列名，避免上游转换丢失信息。
        if not isinstance(X, pd.DataFrame):
            X = pd.DataFrame(X)
        self.feature_names = list(X.columns)

        X = X.reset_index(drop=True)
        T = T.reset_index(drop=True)
        Y = Y.reset_index(drop=True)

        df = pd.concat([X, T, Y], axis=1)
        df.columns = [x for x in X.columns] + ["time", "label"]

        self.model.fit(df, duration_col="time", event_col="label", **kwargs)

        return self

    def predict(self, X: pd.DataFrame, *args: Any, **kwargs: Any) -> pd.DataFrame:
        if len(args) < 1:
            raise ValueError("Invalid input for predict. Expecting X and time horizon.")

        time_horizons = args[0]

        # 保证输入为 DataFrame 并带有列名，避免 lifelines 内部对列操作时报错。
        if not isinstance(X, pd.DataFrame):
            X = pd.DataFrame(
                X,
                columns=getattr(self, "feature_names", None),
            )
        else:
            # 确保列名与训练时一致，避免部分转换丢失原列名。
            if getattr(self, "feature_names", None) is not None:
                X = X.copy()
                X.columns = self.feature_names

        chunks = int(len(X) / 1024) + 1

        preds_ = []
        for idx_chunk in np.array_split(X.index, chunks):
            chunk = X.loc[idx_chunk]
            local_preds_ = np.zeros([len(chunk), len(time_horizons)])
            surv = self.model.predict_survival_function(chunk)
            surv_times = np.asarray(surv.index).astype(int)
            surv = np.asarray(surv.T)

            for t, eval_time in enumerate(time_horizons):
                tmp_time = np.where(eval_time <= surv_times)[0]
                if len(tmp_time) == 0:
                    local_preds_[:, t] = 1.0 - surv[:, 0]
                else:
                    local_preds_[:, t] = 1.0 - surv[:, tmp_time[0]]

            preds_.append(local_preds_)

        return np.concatenate(preds_, axis=0)
